clear all;close all;clc;
setup;

mainDir='Data/iCoseg/image/';
outDir='Data/iCoseg/results/';
ucmDir='Data/iCoseg/UCM/';
bbsDir='Data/iCoseg/edgebox/';
subDir=dir(mainDir);
for j=1:length(subDir) 
    if( isequal(subDir(j).name, '.' ) || ...
        isequal(subDir(j).name, '..' ) || ...
        ~subDir(j).isdir) 
        continue;
    end
    
imgDir=[mainDir subDir(j).name '/'];
sub_outDir=[outDir subDir(j).name '/'];
sub_ucmDir=[ucmDir subDir(j).name '/'];
sub_bbsDir=[bbsDir subDir(j).name '/'];
if exist(sub_outDir,'dir')
    continue;
end
mkdir(sub_outDir);mkdir(sub_ucmDir);mkdir(sub_bbsDir);
%% UCM
% matlabpool 4;
im2UCM(imgDir, sub_ucmDir, para);
%% edgebox
generate_edgebox(model,imgDir,sub_bbsDir,para);

%% CoSaliency
CoSaliency(imgDir,sub_ucmDir,sub_bbsDir,sub_outDir, para);

end



