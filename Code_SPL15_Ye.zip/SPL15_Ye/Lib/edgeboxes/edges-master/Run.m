clear all;close all;clc;
addpath(genpath('toolbox'))
imDir='/media/ylw/数据/DATASET/Co-Saliency/MSRC/ALL/';
D = dir ([imDir '*.bmp'] );
resDir = 'MSRC/';
mkdir(resDir);

%% load pre-trained edge detection model and set opts (see edgesDemo.m)
model=load('models/forest/modelBsds'); model=model.model;
model.opts.multiscale=0; model.opts.sharpen=2; model.opts.nThreads=4;

%% set up opts for edgeBoxes (see edgeBoxes.m)
opts = edgeBoxes;
opts.alpha = .65;     % step size of sliding window search
opts.beta  = .75;     % nms threshold for object proposals
opts.minScore = .01;  % min score of boxes to detect
opts.maxBoxes = 1e3;  % max number of boxes to detect

for i =1: numel(D) 
    disp(i)
image = [imDir D(i).name];
if exist([resDir D(i).name(1:end-4) '_edgebox.mat'], 'file')
   disp('Done!');
 continue;
end
 bbs=edgeBoxes(image,model,opts);
 save([resDir D(i).name(1:end-4) '_edgebox.mat'], 'bbs');
 
end